// Service Worker מינימלי — נדרש כדי שהדפדפן יאפשר "התקנה" של האתר כאפליקציה.
// לא עושה caching אגרסיבי כדי שתמיד תיטען הגרסה העדכנית מהשרת.
self.addEventListener('install', function(event) {
  self.skipWaiting();
});
self.addEventListener('activate', function(event) {
  event.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', function(event) {
  // מעביר בקשות ישירות לרשת (ללא caching) — מבטיח תוכן עדכני תמיד
  event.respondWith(fetch(event.request));
});
